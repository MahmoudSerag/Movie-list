// Load required packages
const ErrorResponse = require('../utils/errorHandling');

// Server error
exports.errorHandling = (err, req, res, next) => {
  
  // Check req.body errors (Bad request)
  const statusCode = 400;
  let message = {};
  if (err.errors) {
    console.log(err.errors);
    for (let key in err.errors) {
      message[key] = err.errors[key].properties.message;
    }
    return res.status(statusCode).json({
      success: false,
      error: {
        code: statusCode,
        message: message
      }
    });
  }



  // Check if invalid Id (Bad request)
  if (err.kind === 'ObjectId') {
    return res.status(statusCode).json({
      success: false,
      error: {
        code: statusCode,
        message: 'Invalid id.'
      }
    });
  }



  // Server error
  res.status(err.statusCode || 500).json({
      success: false,
      error: {
        code: err.statusCode || 500,
        message: err.message || `Server error.`
      }
  });
}