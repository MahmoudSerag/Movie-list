// Load required packages
const express = require('express');
const router = express.Router();
const { getOneMovieById,
        getAllMovies,
        createMovie,
        deleteOneMovieById,
        updateOneMovieById } = require('../controller/movie');




// @des     Get all movies, Create new movie
// @route   { Get, Post } localhost:3000/api/v1/movies
// @access  public
router.route('/api/v1/movies')
    .get(getAllMovies)
    .post(createMovie);




// @des     Get one movie by id, Delete one movie by id, Patch one movie by id
// @route   { Get, Delete, Patch } localhost:3000/api/v1/movies/:movieId
// @access  public
router.route('/api/v1/movies/:movieId')
    .get(getOneMovieById)
    .delete(deleteOneMovieById)
    .patch(updateOneMovieById);




// Export router
module.exports = router;