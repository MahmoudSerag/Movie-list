// Load required packages
const express = require('express');
const mongoose = require('mongoose');
const app = express();
const path = require('path');



// Load routes
const movie = require('./routes/movie');



// Add middleware files
const { errorHandling } = require(`./middlewares/ErrorHandling`);



// Add config files
const connectDB = require(`./config/db`);


// Connect to mongodb
connectDB();



// Read body of request
app.use(express.urlencoded({ extended: false }));
app.use(express.json());



// use routes
app.use(movie);
app.use((req, res, next) => {
    return res.status(404).json({
      success: false,
      error: {
        code: 404,
        message: `this url not found`
      }
    });
  });


// Use error handler
app.use(errorHandling);


const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Listening to server on port ${port}...`);
});