// Load required packages
const Movie = require('../models/movie');
const asyncHandler = require('../middlewares/async');
const ErrorResponse = require('../utils/errorHandling');
const { create } = require('../models/movie');




// @desc    Get one movie by Id
// @route   Get localhost:3000/api/v1/movies/:movieId
// @access  public
exports.getOneMovieById = asyncHandler(async(req, res, next) => {
    
    // Fetch data from db
    const movie = await Movie.findById(req.params.movieId);

    // Check if not found
    if (!movie)
        return next(new ErrorResponse(`No Movie found with Id: ${req.params.movieId}`, 404));


    // Return data to client
    res.status(200).json({
        success: true,
        message: 'Movie Data',
        data: {
          kind: 'Movie',
          items: movie
        }
    });
});




// @desc    Get all movies
// @route   Get localhost:3000/api/v1/movies
// @access  public
exports.getAllMovies = asyncHandler(async(req, res, next) => {
    
    // Fetch data from db
    const movies = await Movie.find();


    // return data to client
    res.status(200).json({
        success: true,
        message: 'Movie Data',
        data: {
          kind: 'Movie',
          items: movies
        }
    });
});




// @desc    Create new movie
// @route   Post localhost:3000/api/v1/movies
// @access  public
exports.createMovie = asyncHandler(async(req, res, next) => {

    // Check imgURL validation
    const isImage = /\.(jpg|jpeg|png|webp|avif|gif|svg)$/;
    if (!isImage.test(req.body.imageURL))
        return next(new ErrorResponse('Invalid image url.', 400));



    // Check year validation
    if (req.body.year < 1930 || req.body.year > new Date().getFullYear() + 1)
        return next(new ErrorResponse(`Year should be in range 1930 - ${new Date().getFullYear() + 1}`, 400));



    // Create new movie and save it in db
    await Movie.create(req.body);
    res.status(201).json({
        success: true,
        message: 'Movie created successfully.'
    });
});




// @desc    Delete movie by Id
// @route   Delete localhost:3000/api/v1/:movieId
// @access  public
exports.deleteOneMovieById = asyncHandler(async(req, res, next) => {

    // Fetch movie data and delete it from db
    const movie = await Movie.findByIdAndDelete(req.params.movieId);

    // Check if invalid Id
    if (!movie)
        return next(new ErrorResponse(`No movie found with Id: ${req.params.movieId}`, 404));
});




// @desc    Update movie by Id
// @route   Put localhost:3000/api/v1/:movieId
// @access  public
exports.updateOneMovieById = asyncHandler(async(req, res, next) => {

    // Fetch movie data and update it from db
    const movie = await Movie.findByIdAndUpdate(req.params.movieId, req.body);

    // Check if invalid Id
    if (!movie)
        return next(new ErrorResponse(`No movie found with Id: ${req.params.movieId}`, 404));


    
    // Create new movie and save it in db
    res.status(200).json({
        success: true,
        message: 'Movie updated successfully.'
    });
});